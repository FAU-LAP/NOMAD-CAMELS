# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'set_channels.ui'
##
## Created by: Qt User Interface Compiler version 6.5.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QSizePolicy, QWidget)

class Ui_Form(object):
    """ """
    def setupUi(self, Form):
        """

        Parameters
        ----------
        Form :
            

        Returns
        -------

        """
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(400, 300)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        """

        Parameters
        ----------
        Form :
            

        Returns
        -------

        """
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
    # retranslateUi

