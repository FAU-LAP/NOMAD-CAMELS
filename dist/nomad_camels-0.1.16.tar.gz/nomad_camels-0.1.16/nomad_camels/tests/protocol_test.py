def test_protocol_config():
    from nomad_camels.frontpanels import protocol_config
    conf = protocol_config.Protocol_Config()